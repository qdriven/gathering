#!/usr/bin/env python
from pydantic import BaseModel


class QBaseModel(BaseModel):
    """
    Base Model Based on pydantic
    """

    pass
