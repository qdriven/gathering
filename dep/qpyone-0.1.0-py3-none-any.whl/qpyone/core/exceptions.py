#!/usr/bin/env python


class RunnerException(Exception):
    pass


class TestCaseException(Exception):
    pass


class ClientException(Exception):
    pass


class DataExtractException(Exception):
    pass
