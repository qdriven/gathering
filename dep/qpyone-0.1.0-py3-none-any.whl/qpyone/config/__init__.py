from .qDynaconf import fsettings as configs
