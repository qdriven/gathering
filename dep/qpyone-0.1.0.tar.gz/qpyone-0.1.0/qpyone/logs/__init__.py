from loguru import logger

from .qlogger import install


install()

flogger = logger
