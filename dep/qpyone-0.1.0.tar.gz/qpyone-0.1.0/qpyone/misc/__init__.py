#!/usr/bin/env python

"""
misc package is for different utilities in daily coding
"""
