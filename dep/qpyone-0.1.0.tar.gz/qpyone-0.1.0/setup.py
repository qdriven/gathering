# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['qpyone',
 'qpyone.builtins',
 'qpyone.builtins.data',
 'qpyone.builtins.dicts',
 'qpyone.clients',
 'qpyone.clients.database',
 'qpyone.clients.http',
 'qpyone.config',
 'qpyone.core',
 'qpyone.logs',
 'qpyone.misc',
 'qpyone.misc.excel',
 'qpyone.misc.validation']

package_data = \
{'': ['*']}

install_requires = \
['Faker>=14.2.0,<15.0.0',
 'Jinja2>=3.1.2,<4.0.0',
 'dynaconf>=3.1.9,<4.0.0',
 'httpx>=0.23.0,<0.24.0',
 'loguru>=0.6.0,<0.7.0',
 'openpyxl>=3.0.10,<4.0.0',
 'psycopg2-binary>=2.9.3,<3.0.0',
 'pydantic>=1.10.2,<2.0.0',
 'rich>=12.5.1,<13.0.0',
 'sqlmodel>=0.0.8,<0.0.9']

setup_kwargs = {
    'name': 'qpyone',
    'version': '0.1.0',
    'description': ' qpyone, a daily qa pytoolkits ',
    'long_description': '# qqyone: Python All-in-One lib for Software QA\n\n<p align="center">\n<a href="https://github.com/qdriven/qpyone/actions"><img alt="Actions Status" src="https://github.com/qdriven/qpyone/workflows/build/badge.svg"></a>\n<a href="https://github.com/qdriven/qpyone/blob/main/LICENSE"><img alt="License: MIT" src="https://black.readthedocs.io/en/stable/_static/license.svg"></a>\n</p>\n\n[![Build status](https://github.com/qdriven/qpyone/workflows/build/badge.svg?branch=main&event=push)](https://github.com/qdriven/qpyone/actions?query=workflow%3Abuild)\n[![Python 3.10](https://img.shields.io/badge/python-3.10-blue.svg)](https://www.python.org/downloads/release/python-310/)\n![coverage](./assets/images/coverage.svg)\n\n***qpyone*** stands, one python lib for QA.\nThis lib integrates most useful libs for QA Daily tasks.\n\n## To Do\n\n- [] DI Implementation\n- [] plugin pattern\n- [] workflow/pipeline pattern\n- [] more enhanced \n',
    'author': 'fluentqa',
    'author_email': 'hello@fluentqa.xyz',
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://github.com/fluentqa/qpyone',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
